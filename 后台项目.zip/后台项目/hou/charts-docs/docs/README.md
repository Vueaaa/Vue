---
home: true
heroText: 实战图形图表
tagline:  基于 Vue 2.6 + EChart 4.0 开发
actionText: 快速上手 →
actionLink: /guide/
features:
- title: Vue 2.6
  details: 基于最新的 Vue 2.6 开发，充分利用 Vue 2.6 的先进特性开发企业级实战项目
- title: ECharts 4.0
  details: 广受欢迎的 javascript 图形库 ECharts 4.0，深度学习和应用
- title: 数据大屏
  details: 企业级的数据大屏项目，开箱即用，快速复制到实际项目

---

# 前置学习
- 具备javascript、html、css的基础
- 具备Vue的使用基础

